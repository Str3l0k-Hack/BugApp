import os 
import time

print('----------------------------------------Burp----------------------------------------')

print('\n1')
time.sleep(1)

print('2')
time.sleep(1)

print('3')
time.sleep(1)

print('4')
time.sleep(1)

os.system('burpsuite')
